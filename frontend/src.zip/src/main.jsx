import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import "@fontsource-variable/inter";
import './i18n/index.js';
import { initTheme } from "./theme.js";
import './index.css';

initTheme();

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
